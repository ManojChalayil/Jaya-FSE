<!-- ## First we need to start mongodb.
- For that use the command
- sudo systemctl start mongod
- to start mongo db

- For running the application we need to use the command 
 - npm start

 - In package .json 'start' command i have given 'ng serve -o | node ./server/bin/www"' so that it will - - start both angular and node js.So that we dont 
 - need to have seperate command for angular and node.

 - By using this command ,sytem will start both mongo db and node js .
 - It will open up in a browser with port number 4200. -->

## How to run the application
- This application is using docker
- First we need to build the docker file
- For that the command used is 'docker-compose build'
- After that we need to run the application using the command 'docker-compose up'
- Afetr that you need to go to 'http://localhost:4200/' for working on the application.

## Description about application

## Register

- Enter username and password and click on register
- You should be able to register for the application

## Login

- Enter username and password and click Login
- If login is successfull the you can see topics.

## Home

- it will show 5 topics in a dashboard.

- Click on each topic you should see questions related to that topic.

- There is a home button provided in the page to come back to the dashboard page.

- When u click on the question you will see answer for that question.

## Add question

- Here there will be button named add question and textarea.

- By using that you canadd questions to that topic.It will in inserted in that database.

## Add comment

- and then click on that question.there also you can see a text area and an add button to enter command 

- enter your command and clcik add command.It will in inserted in that database

## Delete Comment

- There  is option provide to delete a command also.

- On the right side of every command ,you can see a delete button to delete a comment.

- When you click on it,it will be deleted from the database also.

## Logout

- When clicking on Logout you will be redirected to login page
import { HttpClient } from '@angular/common/http';
import { HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { AppService } from './app.service';
describe('webapp App', () => {
    // let service: AppService;
    // beforeEach(() => {
    //     service = new AppService(http: HttpClient);
    // });
    // it('should start with no messages', () => {
    //   expect(service.getTopics.length).toBe(0);
    // });
  });

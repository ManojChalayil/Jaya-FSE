import { Iquestions } from './questions/questions';
import { HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import {Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import {catchError, tap} from 'rxjs/operators';

@Injectable()
export class QuestionsService {
    private questionUrl = 'localhost:8080/api/v1/questions/questions?topicId=2';
    constructor(private http: HttpClient) {

    }
    getQuestion(): Observable<Iquestions[]> {
        return this.http.get<Iquestions[]>(this.questionUrl);
      }
private handleError(err: HttpErrorResponse) {
 const errorMsg = '';
 return errorMsg;

}
}

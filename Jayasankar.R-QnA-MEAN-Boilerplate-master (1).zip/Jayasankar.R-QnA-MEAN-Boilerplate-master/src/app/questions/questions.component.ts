
import { QuestionsService } from '../questions.service';
import { Iquestions } from './questions';
import { AppService } from '../app.service';
import { Router, ActivatedRoute } from '@angular/router';
import { PARAMETERS } from '@angular/core/src/util/decorators';
import 'rxjs/add/operator/filter';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Icomments } from '../comments/comments';
import { Component, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';

@Component({
  templateUrl: './questions.component.html'
})
export class QuestionsComponent implements OnInit {
  questionsList: Iquestions[] = [];
  commentsList: Icomments[] = [];
  // errorMsg: string;
  // selectedRow: Number;
  // setClickedRow: Function;
  // header: string;
  // show = false;
  questId: Number;
  topicId: Number;
  // isVisible = false;
  // isqusVisible = false;
  // isUserLoggedIn = false;
  // isAddTopicVisible = false;
  // selQus = false;
  // inputqust: string;
  // loggedInUserName: string;
  // welcomemsg: string;
  // public frm: FormGroup;
  // public regfrm: FormGroup;
  public commentFrm: FormGroup;
  @ViewChild('inputcomment') inputcomment: ElementRef;
  @ViewChild('inputqus') inputqus: ElementRef;
  @ViewChild('inputtopic') inputtopic: ElementRef;
  // public showInputErrors = false;
  // public showInputErrorsReg = false;
  message: any;
  constructor( private appService: AppService, private fb: FormBuilder,
    private router: ActivatedRoute, private normalrouter: Router) {
    this.commentFrm = fb.group({
      commentTextarea: ['']
    });
  }

 ngOnInit(): void {
  this.router.queryParams
      .filter(params => params.topicId)
      .subscribe(params => {
        console.log('topicId :' + params.topicId); // {order: "popular"}

        this.appService.getQuestion(params.topicId).subscribe({
          next: qus => this.questionsList = qus
        });
      });
 }
 questionclick(questionId, event) {
  console.log(event.target.parentNode.innerText);
  this.questId = questionId;
  // this.isVisible = true;
  this.appService.getcomments(questionId).subscribe({
    next: com => this.commentsList = com
  });
}

addcomment() {
  const comment = this.commentFrm.get('commentTextarea').value;
  this.appService.insertComment(this.questId, comment);
  setTimeout(() => {
  this.appService.getcomments(this.questId).subscribe({
    next: com => this.commentsList = com
  });
  this.inputcomment.nativeElement.value = '';
  this.commentFrm.reset();
},  500);
}
addquestion(question) {
  this.appService.insertQuestion(this.topicId, question);
  setTimeout(() => {
  this.appService.getQuestion(this.topicId).subscribe({
    next: qus => this.questionsList = qus
  });
  this.inputqus.nativeElement.value = '';
},  500);
}
deleteComment(event) {
  console.log('comment id = ' + event.target.attributes.id);
this.appService.deleteComment(event.target.attributes.id);
setTimeout(() => {
  this.appService.getcomments(this.questId).subscribe({
    next: com => this.commentsList = com
  });
},  500);

}
homeclick(event) {
  this.normalrouter.navigateByUrl('/topics');
}


logoutclick() {
  this.normalrouter.navigateByUrl('/login');
}
}

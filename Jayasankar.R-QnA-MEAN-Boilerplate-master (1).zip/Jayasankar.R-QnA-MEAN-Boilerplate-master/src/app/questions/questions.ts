export interface Iquestions {
    Id: number;
    question: string;
    topicId: string;
}


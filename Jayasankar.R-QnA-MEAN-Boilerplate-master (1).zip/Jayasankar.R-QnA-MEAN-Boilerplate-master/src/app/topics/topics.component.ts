import { Iquestions } from './../questions/questions';
import { Component, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Itopics } from './topics';
import { Icomments } from '../comments/comments';
import { useAnimation } from '@angular/core/src/animation/dsl';
import {catchError, tap, map} from 'rxjs/operators';
import { Router } from '@angular/router';
@Component({
  selector: 'app-topics-list',
  templateUrl: './topics.component.html'
})
export class TopicsComponent implements OnInit {
  topicsList: Itopics[] = [];
  // questionsList: Iquestions[] = [];
  // commentsList: Icomments[] = [];
  // errorMsg: string;
  // selectedRow: Number;
  // setClickedRow: Function;
  // header: string;
  // show = false;
  // questId: Number;
  // topicId: Number;
  // isVisible = false;
  // isqusVisible = false;
  // isUserLoggedIn = false;
  // isAddTopicVisible = false;
  // selQus = false;
  // inputqust: string;
  // loggedInUserName: string;
  // welcomemsg: string;
  // public frm: FormGroup;
  // public regfrm: FormGroup;
  public commentFrm: FormGroup;
  @ViewChild('inputcomment') inputcomment: ElementRef;
  @ViewChild('inputqus') inputqus: ElementRef;
  @ViewChild('inputtopic') inputtopic: ElementRef;
  // public showInputErrors = false;
  // public showInputErrorsReg = false;
  message: any;

  constructor( private appService: AppService, private fb: FormBuilder, private router: Router) {
    // this.setClickedRow = function(index) {
    //   this.selectedRow = index;
    // };
  }


 ngOnInit(): void {
  //  this.header = 'Please click on interested topic and view the questions related to that topic.';
this.appService.getTopics().subscribe(
  topicsList => this.topicsList = topicsList
);
 }
// ngOnInit() {
//     this.topicService.getTopics().subscribe((topics) => {
// console.log('data: ' + topics);
// this.topicsList = topics;
//     });
//   }

// notifyMe(event) {
//   console.log(event);
//   this.topicService.getQuestion().subscribe({
//     next: qus => this.questionsList = qus
//   });
// }

topicclick(topicId) {
  // this.header = 'Please click on a question to view comments and add comments.';
  // this.questionsList = [];
  // this.commentsList = [];
  // this.topicsList = [];
  // this.show = true;
  // this.topicId = topicId;
  // this.isqusVisible = true;
  // this.isAddTopicVisible = false;
  // console.log(event.target.attributes.id);
  this.router.navigate(['/questions'], {queryParams: { topicId: topicId }});
  // this.appService.getQuestion(topicId).subscribe({
  //   next: qus => this.questionsList = qus
  // });
}


homeclick(event) {
  this.router.navigateByUrl('/topics');
}


logoutclick() {
  this.router.navigateByUrl('/login');
}
addTopic(topic) {
  console.log(topic);
  if (topic != null && topic !== '') {
  this.appService.insertTopic(topic).subscribe(
    res => {
        this.message = res;
        // JSON.stringify({questionId: qus, comment: comment})
        // return response;
        document.getElementById('topicspan').innerHTML = this.message.message;
          }
          );
  setTimeout(() => {
  this.appService.getTopics().subscribe({
    next: top => this.topicsList = top
  });
  this.inputtopic.nativeElement.value = '';
  },  500);
  } else {
    document.getElementById('topicspan').innerHTML = 'Please enter a topic to add';
  }
}
addcommentforqus() {
  // this.selQus = !this.selQus;
}
}

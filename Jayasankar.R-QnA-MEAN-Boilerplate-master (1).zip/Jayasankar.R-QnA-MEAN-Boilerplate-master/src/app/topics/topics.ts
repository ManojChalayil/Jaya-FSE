export interface Itopics {
    Id: number;
    text: string;
}


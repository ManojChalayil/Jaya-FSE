import { Itopics } from './topics/topics';
import { Iquestions } from './questions/questions';
import { Icomments } from './comments/comments';
import { HttpClientModule, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import { Response, Headers, RequestOptions} from '@angular/http';
import {Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import {catchError, tap, map} from 'rxjs/operators';

@Injectable()
export class AppService {
    private topicUrl = 'http://localhost:8080/api/v1/topics/topics';
    private questionUrl = 'http://localhost:8080/api/v1/questions/questions?topicId=';
    private commentsUrl = 'http://localhost:8080/api/v1/comments/comments?questionId=';
    private insertUrl = 'http://localhost:8080/api/v1/comments/insert?questionId=';
    private insertqusUrl = 'http://localhost:8080/api/v1/questions/insertqus?topicId=';
    private deleteCommentUrl = 'http://localhost:8080/api/v1/comments/deleteComment?commentId=';
    private loginUrl = 'http://localhost:8080/api/v1/user/login?username=';
    private registerUrl = 'http://localhost:8080/api/v1/user/register?username=';
    private insertTopicsUrl = 'http://localhost:8080/api/v1/topics/inserttopic?topic=';
    constructor(private http: HttpClient) {

    }
    // getTopics(): Observable<Itopics[]> {
    //     return this.http.get<Itopics[]>(this.topicUrl).pipe(
    //         tap(data => console.log('All' + JSON.stringify(data)))
    //     );
    // }
    // getTopics() {
    //     return this.http.get(this.topicUrl);
    // }
    getTopics(): Observable<Itopics[]> {
        return this.http.get<Itopics[]>(this.topicUrl);
      }
      getQuestion(id): Observable<Iquestions[]> {
        console.log(this.questionUrl + id);
        return this.http.get<Iquestions[]>(this.questionUrl + id);
      }
      getcomments(id): Observable<Icomments[]> {
        return this.http.get<Icomments[]>(this.commentsUrl + id);
      }
      insertComment(questionId, comment) {
        console.log(this.insertUrl + questionId + '&comment' + comment);
        const qus = questionId;
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        // const options = new RequestOptions({headers: headers});
        this.http.post(this.insertUrl + questionId + '&comment=' + comment,
         {headers: headers}).subscribe(
    res => {
        // const response = res.text();
        // JSON.stringify({questionId: qus, comment: comment})
          }
          );
        // return this.http.post(this.insertUrl + questionId.value + '&comment=' + comment, '');
      }
      insertQuestion(topicId, question) {
        console.log(this.insertqusUrl + topicId + '&question' + question);
        const qus = topicId;
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        // const options = new RequestOptions({headers: headers});
        this.http.post(this.insertqusUrl + topicId + '&question=' + question,
         {headers: headers}).subscribe(
    res => {
        // const response = res.text();
        // JSON.stringify({questionId: qus, comment: comment})
          }
          );
        // return this.http.post(this.insertUrl + questionId.value + '&comment=' + comment, '');
      }
      deleteComment(commentId) {
        console.log(commentId);
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        // const options = new RequestOptions({headers: headers});
        this.http.post(this.deleteCommentUrl + commentId.value,
         {headers: headers}).subscribe(
    res => {
        // const response = res.toString();
        // JSON.stringify({questionId: qus, comment: comment})
          }
          );
      }
      login(username, password) {
        console.log(username + 'p' + password);
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        return this.http.post(this.loginUrl + username + '&password=' + password,
         {headers: headers}).pipe(map( res => {
          return res;
          }));
      }
      register(username, password) {
        console.log(username + 'p' + password);
        // let response = '';
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        // const options = new RequestOptions({headers: headers});
        return this.http.post(this.registerUrl + username + '&password=' + password,
         {headers: headers})
        //  .subscribe(
        //   res => {
        //       const response = res.toString();
        //       // JSON.stringify({questionId: qus, comment: comment})
        //       return response;
        //         }
        //         );
        .pipe(map( res => {
        return res;
        }));
        // .catchError(
        //   err => { return err.message; }
        // );
      }
      insertTopic(topic) {
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        // const options = new RequestOptions({headers: headers});
        return this.http.post(this.insertTopicsUrl + topic,
         {headers: headers}).pipe(map( res => {
          return res;
          }));
        // return this.http.post(this.insertUrl + questionId.value + '&comment=' + comment, '');
      }
private handleError(err: HttpErrorResponse) {
 const errorMsg = '';
 return errorMsg;

}
}

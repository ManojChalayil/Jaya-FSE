export interface Icomments {
    Id: number;
    comment: string;
    questionId: string;
}


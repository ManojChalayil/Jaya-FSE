import { Iquestions } from './../questions/questions';
import { Component, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Icomments } from '../comments/comments';
import { useAnimation } from '@angular/core/src/animation/dsl';
import {catchError, tap, map} from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  templateUrl: './login.component.html',
  styleUrls: ['/login.component.css']
})
export class LoginComponent implements OnInit {
  public frm: FormGroup;
  public regfrm: FormGroup;
  // questionsList: Iquestions[] = [];
  // commentsList: Icomments[] = [];
  // errorMsg: string;
  // selectedRow: Number;
  // setClickedRow: Function;
  // header: string;
  // show = false;
  // questId: Number;
  // topicId: Number;
  // isVisible = false;
  // isqusVisible = false;
  // isUserLoggedIn = false;
  // isAddTopicVisible = false;
  // selQus = false;
  // inputqust: string;
  loggedInUserName: string;
  // welcomemsg: string;
  // public frm: FormGroup;
  // public regfrm: FormGroup;
  public commentFrm: FormGroup;
  @ViewChild('inputcomment') inputcomment: ElementRef;
  @ViewChild('inputqus') inputqus: ElementRef;
  @ViewChild('inputtopic') inputtopic: ElementRef;
  public showInputErrors = false;
  public showInputErrorsReg = false;
  message: any;
  constructor( private appService: AppService, private fb: FormBuilder, private router: Router) {
    this.frm = fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.regfrm = fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
    ngOnInit(): void {
      }
      loginClick() {
        // Make sure form values are valid
        if (this.frm.invalid) {
          this.showInputErrors = true;
          return;
        }
        const username = this.frm.get('username').value;
        const password = this.frm.get('password').value;
        console.log('user' + username + 'pass' + password);
      this.appService.login(username, password).subscribe(
        res => {
              this.message = res;
              if (this.message.status === 201) {
                document.getElementById('loginspn').innerHTML = 'Logged in successfully';
                this.router.navigateByUrl('/topics');
                this.loggedInUserName = username;
              } else {
                document.getElementById('loginspn').innerHTML = this.message.message;
              }
              }
              );
      }
      registerClick() {
        if (this.regfrm.invalid) {
          this.showInputErrorsReg = true;
          return;
        }
        const username = this.regfrm.get('username').value;
        const password = this.regfrm.get('password').value;
        console.log('user' + username + 'pass' + password);
      //  this.appService.register(username, password).subscribe(data =>
      //     this.message = data
      // );
      this.appService.register(username, password).subscribe(
        res => {
            this.message = res;
            // JSON.stringify({questionId: qus, comment: comment})
            // return response;
            document.getElementById('regspan').innerHTML = this.message.message;
              }
              );
      }
}

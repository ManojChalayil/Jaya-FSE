import { AppPage } from './app.po';
import { browser, by, element} from 'protractor';
import { protractor } from 'protractor/built/ptor';
describe('webapp App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display title of site', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Discussion Forum');
  });
  it('should display Login', () => {
        expect(element( by.id('loginTable')).all( by.css('tr'))
        .get(0).all(by.css('td')).get(0).all(by.id('headerLogin')).getText())
        .toContain('Login to our site');
  });
  it('should display Register', () => {
    expect(element( by.id('loginTable')).all( by.css('tr'))
    .get(0).all(by.css('td')).get(1).all(by.css('h2')).getText())
    .toContain('Sign up now');
  });

  // it('should be able to Register user', () => {
  //  browser.element(by.id('regUser')).sendKeys('Super11');
  //  browser.element(by.id('regPass')).sendKeys('Super9');
  //  browser.driver.sleep(3000);
  //  browser.element(by.id('regClick')).click();
  //  expect(browser.element(by.id('regspan')).getText()).toContain('Successfully registered');
  // });
  it('Same user tries to register again,should get validation', () => {
    browser.element(by.id('regUser')).clear();
    browser.element(by.id('regPass')).clear();
    browser.element(by.id('regUser')).sendKeys('super');
    browser.element(by.id('regPass')).sendKeys('super');
    browser.driver.sleep(3000);
    browser.element(by.id('regClick')).click();
    expect(browser.element(by.id('regspan')).getText()).toContain('Username already exists');
   });
   it('Should not be able to login with the wrong password', () => {
    browser.element(by.id('regUser')).clear();
    browser.element(by.id('regPass')).clear();
    browser.element(by.id('loginUser')).sendKeys('Super');
    browser.element(by.id('loginPass')).sendKeys('Super1');
    browser.driver.sleep(6000);
    browser.element(by.id('loginbutton')).click();
    expect(browser.element(by.id('loginspn')).getText()).toContain('Password is incorrect');
   });
   it('Should be able to login with an unregistered user', () => {
    browser.element(by.id('loginUser')).clear();
    browser.element(by.id('loginPass')).clear();
    browser.element(by.id('loginUser')).sendKeys('Super1');
    browser.element(by.id('loginPass')).sendKeys('Super');
    browser.driver.sleep(6000);
    browser.element(by.id('loginbutton')).click();
    expect(browser.element(by.id('loginspn')).getText()).toContain('You are not registered user');
   });
   it('Should be able to login with the user', () => {
    browser.element(by.id('loginUser')).clear();
    browser.element(by.id('loginPass')).clear();
    browser.element(by.id('loginUser')).sendKeys('Super');
    browser.element(by.id('loginPass')).sendKeys('Super');
    browser.driver.sleep(6000);
    browser.element(by.id('loginbutton')).click();
    expect(browser.element(by.name('logout')).getText()).toContain('Log out');
   });
     it('Should be able to save a topic', () => {
    browser.element(by.id('topicTextbox')).clear();
    browser.element(by.id('topicTextbox')).sendKeys('News11');
    browser.driver.sleep(3000);
    browser.element(by.name('addTopic')).click();
    expect(browser.element(by.id('topicspan')).getText()).toContain('Topic added successfully');
   });
   it('Should not be able to save a topic with same name', () => {
    browser.element(by.id('topicTextbox')).clear();
    browser.element(by.id('topicTextbox')).sendKeys('News');
    browser.driver.sleep(6000);
    browser.element(by.name('addTopic')).click();
    expect(browser.element(by.id('topicspan')).getText()).toContain('Topic already exists');
   });

  it('Should be able to click on topic', () => {
    //   browser.element.all(by.css('mat-list-item')).each(function (eachElement, index) {
    //     eachElement.click();
    //     browser.driver.sleep(500);
    //     element(by.css('button')).click();
    //     browser.driver.sleep(3000);
    //     expect(browser.element(by.name('logout')).getText()).toContain('Log out');
    //  });
    browser.element(by.id('1')).click();
    browser.driver.sleep(6000);
    expect(browser.element(by.name('logout')).getText()).toContain('Log out');
    });

    it('Should be able to click on question to see comments related to that', () => {
      //   browser.element.all(by.css('mat-list-item')).each(function (eachElement, index) {
      //     eachElement.click();
      //     browser.driver.sleep(500);
      //     element(by.css('button')).click();
      //     browser.driver.sleep(3000);
      //     expect(browser.element(by.name('logout')).getText()).toContain('Log out');
      //  });
      browser.element(by.id('4')).click();
      browser.driver.sleep(6000);
      expect(browser.element(by.name('addcomment')).getText()).toContain('Add comment');
      });
  it('Should be able to logout', () => {
  browser.element(by.name('logout')).click();
  expect(element( by.id('loginTable')).all( by.css('tr'))
        .get(0).all(by.css('td')).get(0).all(by.id('headerLogin')).getText())
        .toContain('Login to our site');
  });
});

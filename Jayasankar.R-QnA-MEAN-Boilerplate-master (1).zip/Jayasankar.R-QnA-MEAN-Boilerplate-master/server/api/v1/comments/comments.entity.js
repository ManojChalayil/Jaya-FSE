let mongoose = require('mongoose');

// define the noteSchema model
let Schema = mongoose.Schema;
const CommentsSchema = new Schema({
  id: {
    type: String,
    required: true
  },
  
  comment: {
    type: String,
    required: true
  },
  questionId: {
    type: String,
    required: true
  }
  
});

module.exports = mongoose.model('comments', CommentsSchema);

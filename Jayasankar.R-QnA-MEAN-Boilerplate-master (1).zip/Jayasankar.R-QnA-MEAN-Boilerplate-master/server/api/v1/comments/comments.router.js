const router = require('express').Router();
const commentsCtrl = require('./comments.controller');
const logger = require('../../../logger');




// api to get all QnA into database
router.get('/comments', (req, res) => {
  logger.debug('Inside comments.router getAllCommentsBasedonQId');
  let questionId = req.query.questionId;
  try {
    commentsCtrl.getAllCommentsBasedonQId(questionId).then((response) => {
      logger.debug('Inside commentsCtrl.getAllCommentsBasedonQId success');
      res.status(response.status).send(response.comments);
    }, 
    (err) => {
      logger.error('Error in commentsCtrl.getAllCommentsBasedonQId error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in commentsCtrl.getAllCommentsBasedonQId ', err);
    res.send({message: 'Failed to complete request'})
  }
});
// api to add a comment
router.post('/insert', (req, res) => {
  logger.debug('Inside comments.router addcomment');
  let comment = req.query.comment;
  let questionId = req.query.questionId;
  try {
    commentsCtrl.addComment(questionId, comment).then((response) => {
      logger.debug('Inside commentsCtrl.addComment success');
      logger.info(response.message);
      res.status(response.status).send(response.note);
    }, 
    (err) => {
      logger.error('Error in commentsCtrl.addComment error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in commentsCtrl.addComment ', err);
    res.send({message: 'Failed to complete request'})
  }
});
router.post('/deleteComment', (req, res) => {
  logger.debug('Inside comments.router deleteComment');
  let commentId = req.query.commentId;
  try {
    commentsCtrl.deleteComment(commentId).then((response) => {
      logger.debug('Inside commentsCtrl.deleteComment success');
      logger.info(response.message);
      res.status(response.status).send(response.note);
    }, 
    (err) => {
      logger.error('Error in commentsCtrl.deleteComment error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in commentsCtrl.deleteComment ', err);
    res.send({message: 'Failed to complete request'})
  }
});

module.exports = router;

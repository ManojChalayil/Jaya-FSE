let commentsDAO = require('./comments.dao');
const logger = require('../../../logger');
const getAllCommentsBasedonQId = (questionId) => {
    logger.debug('Inside comments.service getAllQuestions method');
    return commentsDAO.getAllCommentsBasedonQId(questionId);
  };

// handels to insert newly created note into the database
const addComment = (questionId, comment) => {
  logger.debug('Inside comment.service addComment method');
  return commentsDAO.addComment(questionId, comment);
};
const deleteComment = (commentId) => {
  logger.debug('Inside comment.service deleteComment method');
  return commentsDAO.deleteComment(commentId);
};
module.exports = {
    
    getAllCommentsBasedonQId,
    addComment,
    deleteComment
    
  }
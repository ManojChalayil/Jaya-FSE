const commentsService =  require('./comments.service')
const logger = require('../../../logger');

const getAllCommentsBasedonQId = (questionId) => {
    logger.debug('Inside questions.controller getAllQuestions method');
    return commentsService.getAllCommentsBasedonQId(questionId);
  }
// Handler to add a note into a database
const addComment = (questionId, comment) => {
  logger.debug('Inside comment.controller addComment method');
  return commentsService.addComment(questionId, comment);
}

const deleteComment = (commentId) => {
  logger.debug('Inside comment.controller deleteComment method');
  return commentsService.deleteComment(commentId);
}
  module.exports = {
    
    getAllCommentsBasedonQId,
    addComment,
    deleteComment
  }
  
let commentsModel = require('./comments.entity');
const logger = require('../../../logger');
const uuidv1 = require('uuid/v1');

const getAllCommentsBasedonQId = (questionId) => {
    logger.debug('Inside questions.dao getAllCommentsBasedonQId method');
    return new Promise((resolve, reject) => {
        commentsModel.find({questionId :questionId}, (err, comments) => {
        if (err) {
          logger.error(err);
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({comments: comments, status:200});
        }
      });
    })
  };

  // handels to insert newly created note into the database
const addComment = (questionId, comment) => {
  logger.debug('Inside comment.dao addComment method');
  return new Promise((resolve, reject) => {
    let newComment = new commentsModel();
    newComment.id = uuidv1();
    newComment.comment = comment;
    newComment.questionId = questionId;
    
    newComment.save((err, note) => {
      if(err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({note: note, message: 'comment added successfully', status:201});
      }
    });
});
};

const deleteComment = (commentId) => {
  logger.debug('Inside questions.dao deleteComment method'+commentId);
  return new Promise((resolve, reject) => {
      commentsModel.remove({id :commentId}, (err, comments) => {
      if (err) {
        logger.error(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({comments: 'deleted', status:200});
      }
    });
  })
};
  module.exports = {
    getAllCommentsBasedonQId,
    addComment,
    deleteComment
  }

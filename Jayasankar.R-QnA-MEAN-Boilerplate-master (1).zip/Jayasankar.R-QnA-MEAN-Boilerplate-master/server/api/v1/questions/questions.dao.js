let questionsModel = require('./questions.entity');
const logger = require('../../../logger');
const uuidv1 = require('uuid/v1');
const getAllQuestions = (topicId) => {
    logger.debug('Inside questions.dao getAllQuestions method');
    return new Promise((resolve, reject) => {
        questionsModel.find({topicId :topicId}, (err, questions) => {
        if (err) {
          logger.error(err);
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({questions: questions, status:200});
        }
      });
    })
  };
  const addQuestion = (topicId, question) => {
    logger.debug('Inside questions.dao addQuestion method');
    return new Promise((resolve, reject) => {
      let newComment = new questionsModel();
      newComment.id = uuidv1();
      newComment.question = question;
      newComment.topicId = topicId;
      
      newComment.save((err, note) => {
        if(err) {
          logger.error(err);
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({note: note, message: 'Question is added successfully', status:201});
        }
      });
  });
  };
  module.exports = {
    getAllQuestions,
    addQuestion
  }

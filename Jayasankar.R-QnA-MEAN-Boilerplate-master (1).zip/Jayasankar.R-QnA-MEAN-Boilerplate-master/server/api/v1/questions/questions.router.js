const router = require('express').Router();
const questionsCtrl = require('./questions.controller');
const logger = require('../../../logger');




// api to get all QnA into database
router.get('/questions', (req, res) => {
  logger.debug('Inside questions.router getAllQuestions');
  let topicId = req.query.topicId;
  try {
    questionsCtrl.getAllQuestions(topicId).then((response) => {
      logger.debug('Inside questionscontroller.getAllQuestions success');
      res.status(response.status).send(response.questions);
    }, 
    (err) => {
      logger.error('Error in questionscontroller.getAllQuestions error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in questionscontroller.getAllQuestions ', err);
    res.send({message: 'Failed to complete request'})
  }
});

router.post('/insertqus', (req, res) => {
  logger.debug('Inside question.router insertqus');
  let question = req.query.question;
  let topicId = req.query.topicId;
  try {
    questionsCtrl.addQuestion(topicId, question).then((response) => {
      logger.debug('Inside questionsCtrl.insertqus success');
      logger.info(response.message);
      res.status(response.status).send(response.note);
    }, 
    (err) => {
      logger.error('Error in questionsCtrl.insertqus error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in questionsCtrl.insertqus ', err);
    res.send({message: 'Failed to complete request'})
  }
});
module.exports = router;

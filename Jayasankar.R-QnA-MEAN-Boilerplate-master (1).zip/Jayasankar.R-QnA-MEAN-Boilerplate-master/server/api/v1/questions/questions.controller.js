const questionsService =  require('./questions.service')
const logger = require('../../../logger');

const getAllQuestions = (topicId) => {
    logger.debug('Inside questions.controller getAllQuestions method');
    return questionsService.getAllQuestions(topicId);
  }
  const addQuestion = (topicId, question) => {
    logger.debug('Inside question.controller addQuestion method');
    return questionsService.addQuestion(topicId, question);
  }
  module.exports = {
    
    getAllQuestions,
    addQuestion
  }
  
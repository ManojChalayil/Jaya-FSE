let mongoose = require('mongoose');

// define the noteSchema model
let Schema = mongoose.Schema;
const QuestionsSchema = new Schema({
  id: {
    type: String,
    required: true
  },
  
  question: {
    type: String,
    required: true
  },
  topicId: {
    type: String,
    required: true
  }
  
});

module.exports = mongoose.model('questions', QuestionsSchema);

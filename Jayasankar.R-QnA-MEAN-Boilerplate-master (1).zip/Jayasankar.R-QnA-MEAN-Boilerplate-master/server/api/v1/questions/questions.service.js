let questionsDAO = require('./questions.dao');
const logger = require('../../../logger');
const getAllQuestions = (topicId) => {
    logger.debug('Inside questions.service getAllQuestions method');
    return questionsDAO.getAllQuestions(topicId);
  };
  const addQuestion = (topicId, question) => {
    logger.debug('Inside questions.service addQuestion method');
    return questionsDAO.addQuestion(topicId, question);
  };

module.exports = {
    
    getAllQuestions,
    addQuestion
    
  }
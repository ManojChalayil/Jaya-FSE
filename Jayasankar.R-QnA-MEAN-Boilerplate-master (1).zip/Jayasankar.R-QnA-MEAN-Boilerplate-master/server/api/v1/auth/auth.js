let bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { authConfig } = require('../../../config').appConfig;

// handler to compare password
const comparePassword = (givenPW, savedPW, cb) => {
  bcrypt.compare(givenPW, savedPW, function(err, isMatch) {
    if(err) {
      cb(err);
    }
    cb(null, isMatch);
  });
};

// handler to generate token
// const generateToken = (payload, done) => {
//   jwt.sign(payload, authConfig.jwtSecret, {expiresIn: '10h'}, done);
// }
const generateToken = (payload,jwtSecret,expiry, done) => {
  jwt.sign(payload, jwtSecret, {expiresIn: expiry}, done);
}
// handler to verify token
const verifyToken = (token, jwtSecret,done) => {
  jwt.verify(token,jwtSecret, done);
}
// const verifyToken = (token, done) => {
//   jwt.verify(token, authConfig.jwtSecret, done);
// }
// handler to protect all api
// const isAuthenticatedUser = (req, res, next) => {
//   logger.debug(req);
//   const authorizationHeader = req.get('Authorization');
//   if(!authorizationHeader) {
//     res.status(401).json({isAuthenticated: false});
//   }
//   console.log(authorizationHeader);
//   const token = authorizationHeader.replace('Bearer ', '');
//   console.log(token);
//   verifyToken(token, (err, decoded) => {
//     if(err) {
//       res.status(401).json({isAuthenticated: false});
//     } else {
//       req.userId = decoded.userId;
//       next();
//    }
//  })
// }

// const isAuthenticatedUser = (authorizationHeader) => {
//   if(!authorizationHeader) {
//     done(null,false);
//   }
//   //console.log(authorizationHeader);
//   const token = authorizationHeader.replace('Bearer ', '');
//   //console.log(token);
//   verifyToken(token, (err, decoded) => {
//     if(err) {
//       done(null,false);
//     } else {
//       done(null,decoded.userId);
//    }
//  })
// }
module.exports = {
  comparePassword,
  generateToken,
  verifyToken
}

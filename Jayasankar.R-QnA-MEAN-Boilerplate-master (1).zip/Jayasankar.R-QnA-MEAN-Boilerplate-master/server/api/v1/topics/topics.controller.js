const topicsService =  require('./topics.service')
const logger = require('../../../logger');

const getTopics = () => {
    logger.debug('Inside topics.controller getTopics method');
    return topicsService.getTopics();
  }
  const addTopic = (topic) => {
    logger.debug('Inside topics.controller addTopic method' +topic);
    return topicsService.addTopic(topic);
  }
  module.exports = {
    
    getTopics,
    addTopic
  }
  
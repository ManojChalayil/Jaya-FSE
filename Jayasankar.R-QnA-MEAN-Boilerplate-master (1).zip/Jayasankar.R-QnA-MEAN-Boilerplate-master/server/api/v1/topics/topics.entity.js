let mongoose = require('mongoose');

// define the noteSchema model
let Schema = mongoose.Schema;
const TopicSchema = new Schema({
  id: {
    type: String,
    required: true
  },
  
  text: {
    type: String,
    required: true
  }
  
});

module.exports = mongoose.model('topics', TopicSchema);

let topicsDAO = require('./topics.dao');
const logger = require('../../../logger');
const getTopics = () => {
    logger.debug('Inside topics.service getTopics method');
    return topicsDAO.getTopics();
  };
  const addTopic = (topic) => {
    logger.debug('Inside topics.service addTopic method');
    return topicsDAO.addTopic(topic);
  };

module.exports = {
  getTopics,
  addTopic
    
  }
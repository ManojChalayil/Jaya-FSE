const router = require('express').Router();
const topicsCtrl = require('./topics.controller');
const logger = require('../../../logger');
// const passport = require('passport');
// const auth = require('../auth')
const { authConfig } = require('../../../config').appConfig;



// api to get all QnA into database
router.get('/topics', (req, res) => {
  logger.debug('Inside QnA.router getTopics');
//   let userId = req.query.userId;
  try {
    topicsCtrl.getTopics().then((response) => {
      logger.debug('Inside topicsCtrl.getTopics success');
      res.status(response.status).send(response.topics);
    }, 
    (err) => {
      logger.error('Error in topicsCtrl.getTopics error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in topicsCtrl.getNotes ', err);
    res.send({message: 'Failed to complete request'})
  }
});

router.post('/inserttopic', (req, res) => {
  logger.debug('Inside topic.router insertqus '+req.query.topic);
  let topic = req.query.topic;
  try {
    topicsCtrl.addTopic(topic).then((response) => {
      logger.debug('Inside topic.inserttopic success');
      logger.info(response.message);
      res.status(response.status).send(response);
    }, 
    (err) => {
      logger.error('Error in topic.inserttopic error: ', err.message);
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    logger.error('Unexpected error in topic.inserttopic ', err);
    res.send({message: 'Failed to complete request'})
  }
});
module.exports = router;

let topicModel = require('./topics.entity');
const logger = require('../../../logger');
const uuidv1 = require('uuid/v1');

const getTopics = () => {
    logger.debug('Inside topics.dao getTopics method');
    return new Promise((resolve, reject) => {
      topicModel.find((err, topics) => {
        if (err) {
          logger.error(err);
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({topics: topics, status:200});
        }
      });
    })
  };
  const addTopic = (topic) => {
    logger.debug('Inside topics.dao addTopic method');
    return new Promise((resolve, reject) => {
      let newtopic = new topicModel();
      newtopic.id = uuidv1();
      newtopic.text = topic;
      topicModel.findOne({text: topic}, function(err, topic) {
        //console.log(user);
        if(topic) {
          reject({message: 'Topic already exists', status: 200});
        } else  {
          newtopic.save((err, note) => {
            if(err) {
              logger.error(err);
              reject({message: 'Internal Server Error', status: 500});
            } else {
              resolve({note: note, message: 'Topic added successfully', status:201});
            }
          });
        }
      });
  });
  };
  module.exports = {
    getTopics,
    addTopic
  }

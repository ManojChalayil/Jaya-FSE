const usersDAO = require('./user.dao');
const logger = require('../../../logger');

const loginUser = (user) => {
  logger.debug('Inside users.usersDAO loginUser method');
  return usersDAO.loginUser(user);
}

const registerUser = (userDetails) => {
  logger.debug('Inside users.service registerUser method');
  return usersDAO.registerUser(userDetails);
}

module.exports = {
  registerUser,
  loginUser
}

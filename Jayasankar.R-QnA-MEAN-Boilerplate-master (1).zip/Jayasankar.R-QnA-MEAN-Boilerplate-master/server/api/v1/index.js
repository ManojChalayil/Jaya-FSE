const router = require('express').Router();

router.use('/topics',require('./topics'));
router.use('/questions',require('./questions'));
router.use('/comments',require('./comments'));
router.use('/user',require('./user'));
module.exports = router;

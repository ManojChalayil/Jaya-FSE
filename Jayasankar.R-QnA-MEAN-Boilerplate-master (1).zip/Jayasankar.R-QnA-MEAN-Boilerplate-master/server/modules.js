const db = require('./db');

/* Replace undefined with Require of your Mongoose connection initialization method */
const initializeMongooseConnection = db.createMongoConnection();
/* Replace undefined with Require of your note entity*/
const qnaModel = require('./api/v1/qna/qna.entity.js');

module.exports = {
	initializeMongooseConnection,
	qnaModel
}
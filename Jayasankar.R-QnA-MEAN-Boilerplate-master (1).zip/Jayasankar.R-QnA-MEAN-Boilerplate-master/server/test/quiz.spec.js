const should = require('chai').should();
const expect = require('chai').expect;
const request = require('supertest');
const app = require('../app');
describe('Testing to get all topics', function()
{
  //  testcase
  it('Should handle a request to get all topics ', function(done)
  {
    // Should get all note as a array those are created by user 1 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 1
    request(app)
    .get('/api/v1/topics/topics')
    .end((err,res)=>{
      if(err)return done(err);
      expect(res!= null);
      done();
    })
  });
});
describe('Testing to get questions based on topic', function()
{
  //  testcase
  it('Should handle a request to get questions based on topic', function(done)
  {
    // Should get all note as a array those are created by user 1 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 1
    request(app)
    .get('/api/v1/questions/questions')
    .query({topicId: "1"})
    .end((err,res)=>{
      if(err)return done(err);
      expect(res!= null);
      done();
    })
  });
});
describe('Testing to get comment based on question', function()
{
  //  testcase
  it('Should handle a request to get  questions based on question', function(done)
  {
    // Should get all note as a array those are created by user 1 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 1
    request(app)
    .get('/api/v1/comments/comments')
    .query({questionId: "1"})
    .end((err,res)=>{
      if(err)return done(err);
      expect(res!= null);
      done();
    })
  });

  it('Should handle a request to add a new comment', function(done)
  {
    // Should get added note of user 1 as a respone,  need to match added note text value
    // status = 201
    // response will be added note object
    request(app)
    .post('/api/v1/comments/insert')
    .query({questionId: "39a1fc80-f0a8-11e9-abc0-d1af762023d2",comment : 'cpu'})
    .expect(201)
    .end((err,res)=>{
      if(err)return done(err);
      expect(res.body!= null);
      done();
    })
  });
});

